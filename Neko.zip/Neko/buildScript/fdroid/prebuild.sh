#!/bin/bash

buildScript/init/action/gradle.sh

# Build libcore
buildScript/lib/core.sh
