#!/bin/bash

buildScript/lib/core/init.sh
buildScript/lib/core/build.sh